# @otlicense

# Python standard
import os
from pathlib import Path
from typing import Optional

class Config:

    def __init__(self) -> None:
        self._ca_certificate_path: Path = None
        self._frontend_app_path: Path = None

        self.determine_ca_certificate_path()
        self.determine_frontend_app_path()

    @property
    def ca_certificate_path(self) -> Optional[Path]:
        return self._ca_certificate_path

    @property
    def frontend_app_path(self) -> Optional[Path]:
        return self._frontend_app_path

    ################################################################################################################################

    # Overridable methods

    def determine_ca_certificate_path(self) -> Optional[Path]:
        cert_dir = os.environ.get("OPEN_TWIN_CERTS_PATH")
                        
        if cert_dir:
            self._ca_certificate_path = Path(cert_dir) / "ca.pem"
        else:
            self._ca_certificate_path = None
        
        return self._ca_certificate_path

    def determine_frontend_app_path(self) -> Optional[Path]:

        return self._frontend_app_path