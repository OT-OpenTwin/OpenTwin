# @otlicense

# Python standard
import sys
from pathlib import Path

# External dependencies
from platformdirs import user_data_dir as platformdirs_user_data_dir
from platformdirs import user_config_dir as platformdirs_user_config_dir
from platformdirs import user_cache_dir as platformdirs_user_cache_dir
 
class DirectoryManager:
    @staticmethod
    def get_local_user_data_directory() -> Path:
        return Path(platformdirs_user_data_dir("OpenTwin", appauthor=False))

    @staticmethod
    def get_existing_local_frontend_installation_directory() -> Path | None:
        path = Path(platformdirs_user_data_dir("OpenTwin_Frontend", appauthor=False))
        if path.is_dir():
            return path
        else:
            return None

    @staticmethod
    def get_existing_local_frontend_application_directory() -> Path | None:
        application_path = DirectoryManager.get_existing_local_frontend_installation_directory()
        if sys.platform == "win32":
            application_path = application_path / "OpenTwinFrontend.exe"
        elif sys.platform == "darwin":
            application_path = application_path / "OpenTwinFrontend"
        else:
            application_path = application_path / "OpenTwinFrontend"

        if application_path.is_file():
            return application_path
        else:
            return None

    @staticmethod
    def get_local_user_config_directory() -> Path:
        return Path(platformdirs_user_config_dir("OpenTwin", appauthor=False))

    @staticmethod
    def get_local_user_cache_directory() -> Path:
        return Path(platformdirs_user_cache_dir("OpenTwin", appauthor=False))